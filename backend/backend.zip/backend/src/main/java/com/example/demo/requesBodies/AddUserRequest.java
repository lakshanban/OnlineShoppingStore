package com.example.demo.requesBodies;

public class AddUserRequest {

	
	public String username;
	public String fname;
	public String lname;
	public String address;
	public String cnumber;
	public String usertype;
	
	public String bday;
	public String password;
	public String email;
}
