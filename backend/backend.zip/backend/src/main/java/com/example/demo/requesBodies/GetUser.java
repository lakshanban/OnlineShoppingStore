package com.example.demo.requesBodies;

public class GetUser {

    public String username;
}
