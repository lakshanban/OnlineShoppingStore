package com.example.demo.requesBodies;

public class UserLoginRequest {
	
	public String username;
	public String password;

}
